"""
漫剧质量评分工具。

用法:
    python scripts/video_scorer.py <task_folder>
"""

import json
import os
import sys


def score_video(task_folder: str) -> dict:
    task_folder = task_folder.rstrip("/\\")

    script_path = os.path.join(task_folder, "script.md")
    script_preview = ""
    if os.path.exists(script_path):
        with open(script_path, encoding="utf-8") as file:
            script_preview = file.read()[:500]

    videos_dir = os.path.join(task_folder, "视频", "第一集")
    asset_dirs = [
        os.path.join(task_folder, "人物资产"),
        os.path.join(task_folder, "场景资产"),
        os.path.join(task_folder, "道具资产"),
    ]

    video_count = (
        len([name for name in os.listdir(videos_dir) if name.lower().endswith(".mp4")])
        if os.path.isdir(videos_dir)
        else 0
    )
    asset_count = 0
    for assets_dir in asset_dirs:
        if not os.path.isdir(assets_dir):
            continue
        for _root, _dirs, files in os.walk(assets_dir):
            asset_count += len(
                [
                    name
                    for name in files
                    if name.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
                ]
            )
    has_final = any(
        name.lower().endswith(".mp4") and os.path.isfile(os.path.join(task_folder, name))
        for name in (os.listdir(task_folder) if os.path.isdir(task_folder) else [])
    )

    score = 0
    score += 2 if script_preview else 0
    score += 2 if asset_count > 0 else 0
    score += 3 if video_count > 0 else 0
    score += 3 if has_final else 0

    suggestions = []
    if not script_preview:
        suggestions.append("补齐 script.md，方便复盘剧情和对白")
    if asset_count == 0:
        suggestions.append("补齐人物、场景、道具参考资产")
    if video_count == 0:
        suggestions.append("生成分镜视频后再做最终质检")
    if not has_final:
        suggestions.append("合成最终 mp4 后再交付")
    if not suggestions:
        suggestions.append("文件完整性通过，继续人工检查人物一致性、脸部稳定性和对白同步")

    evaluation = "\n".join(
        [
            f"完整性评分: {score}/10",
            f"剧本: {'存在' if script_preview else '缺失'}",
            f"参考资产: {asset_count} 张",
            f"分镜视频: {video_count} 段",
            f"最终成片: {'存在' if has_final else '缺失'}",
            "建议: " + "；".join(suggestions),
        ]
    )

    return {
        "task_folder": task_folder,
        "evaluation": evaluation,
        "stats": {
            "video_count": video_count,
            "asset_count": asset_count,
            "has_final": has_final,
            "score": score,
        },
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python scripts/video_scorer.py <task_folder>")
        sys.exit(1)

    result = score_video(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
