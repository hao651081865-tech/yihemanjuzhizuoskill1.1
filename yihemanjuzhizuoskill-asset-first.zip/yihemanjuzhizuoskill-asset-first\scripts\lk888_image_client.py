import json
import os
import shutil
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Callable, Iterable


DEFAULT_BASE_URL = "https://api.lk888.ai"
DEFAULT_MODEL = "gpt-image-2"
DEFAULT_SIZE = "auto"
DEFAULT_QUALITY = "auto"
DEFAULT_TIMEOUT = 600
DEFAULT_POLL_INTERVAL = 5
DEFAULT_ASSET_DIR = r"D:\codex资产"


def get_env_value(name: str) -> str | None:
    if os.name == "nt":
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
                value, _ = winreg.QueryValueEx(key, name)
                if value:
                    return str(value)
        except OSError:
            pass
    value = os.getenv(name)
    if value:
        return value
    return None


def get_api_key() -> str:
    api_key = (
        get_env_value("LK888_API_KEY")
        or get_env_value("MODEL_IMAGE_API_KEY")
        or get_env_value("MODEL_AGENT_API_KEY")
        or get_env_value("API_KEY")
    )
    if not api_key:
        raise RuntimeError(
            "Missing API key. Set LK888_API_KEY, MODEL_IMAGE_API_KEY, MODEL_AGENT_API_KEY, or API_KEY."
        )
    return api_key


def build_generate_payload(
    prompt: str,
    image_urls: Iterable[str] | None = None,
    size: str | None = None,
    quality: str | None = None,
    model: str | None = None,
) -> dict:
    params = {
        "size": size or os.getenv("LK888_IMAGE_SIZE", DEFAULT_SIZE),
        "quality": quality or os.getenv("LK888_IMAGE_QUALITY", DEFAULT_QUALITY),
    }

    images = [url for url in image_urls or [] if url]
    if images:
        params["images"] = images

    return {
        "model": model or os.getenv("LK888_IMAGE_MODEL", DEFAULT_MODEL),
        "prompt": prompt,
        "params": params,
    }


def extract_direct_url(response: dict) -> str | None:
    data = response.get("data")
    if isinstance(data, list) and data:
        first = data[0]
        if isinstance(first, dict) and first.get("url"):
            return first["url"]
    return None


def extract_task_id(response: dict):
    for key in ("task_id", "id"):
        if response.get(key):
            return response[key]

    data = response.get("data")
    if isinstance(data, dict):
        for key in ("task_id", "id"):
            if data.get(key):
                return data[key]
        task_ids = data.get("task_ids") or data.get("任务ids")
        if isinstance(task_ids, list) and task_ids:
            return task_ids[0]

    return None


def default_request_json(method: str, url: str, api_key: str, payload: dict | None = None) -> dict:
    data = None
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")

    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Network error: {exc.reason}") from exc


def default_download_file(url: str, filepath: str) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": "codex-comic-drama/1.0"})
    with urllib.request.urlopen(request, timeout=120) as response:
        Path(filepath).write_bytes(response.read())


def mirror_to_asset_dir(filepath: str) -> str | None:
    # Assets are generated directly into the canonical output directory.
    # Do not mirror/copy them elsewhere; duplicate local files break the skill rules.
    return None


class Lk888ImageClient:
    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        request_json: Callable | None = None,
        download_file: Callable | None = None,
        sleep: Callable[[float], None] | None = None,
    ):
        self.api_key = api_key or get_api_key()
        self.base_url = (base_url or os.getenv("LK888_BASE_URL", DEFAULT_BASE_URL)).rstrip("/")
        self._request_json = request_json
        self._download_file = download_file or default_download_file
        self._sleep = sleep or time.sleep

    def request_json(self, method: str, url: str, payload: dict | None = None) -> dict:
        if self._request_json:
            return self._request_json(method, url, payload)
        return default_request_json(method, url, self.api_key, payload)

    def create_image(
        self,
        prompt: str,
        image_urls: Iterable[str] | None = None,
        size: str | None = None,
        quality: str | None = None,
    ) -> dict:
        payload = build_generate_payload(prompt, image_urls, size, quality)
        return self.request_json("POST", f"{self.base_url}/v1/media/generate", payload)

    def poll_task(
        self,
        task_id,
        interval: int = DEFAULT_POLL_INTERVAL,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> tuple[str, dict]:
        deadline = time.time() + timeout
        query = urllib.parse.urlencode({"task_id": task_id})
        status_url = f"{self.base_url}/v1/media/status?{query}"

        while time.time() < deadline:
            result = self.request_json("GET", status_url)
            state = result.get("state")
            progress = result.get("progress", "")
            print(f"status: state={state}, progress={progress}", flush=True)

            if result.get("is_final") is True:
                if state == "success" and result.get("result_url"):
                    return result["result_url"], result
                raise RuntimeError(f"Image task failed: {result.get('error') or result}")

            self._sleep(interval)

        raise TimeoutError(f"Image task {task_id} did not finish within {timeout} seconds")

    def generate_image(
        self,
        prompt: str,
        output_dir: str,
        filename: str,
        image_urls: Iterable[str] | None = None,
        size: str | None = None,
        quality: str | None = None,
        poll_interval: int = DEFAULT_POLL_INTERVAL,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> list[str]:
        if not prompt:
            raise ValueError("Prompt is empty.")

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        filepath = output_path / filename

        response = self.create_image(prompt, image_urls=image_urls, size=size, quality=quality)
        print(json.dumps(response, ensure_ascii=False, indent=2), flush=True)

        result_url = extract_direct_url(response)
        if not result_url:
            task_id = extract_task_id(response)
            if not task_id:
                raise RuntimeError(f"No direct URL or task_id found in response: {response}")
            print(f"task_id={task_id}", flush=True)
            result_url, _ = self.poll_task(task_id, interval=poll_interval, timeout=timeout)

        self._download_file(result_url, str(filepath))
        print(f"Saved to: {filepath}", flush=True)
        mirrored = mirror_to_asset_dir(str(filepath))
        if mirrored:
            print(f"Mirrored to: {mirrored}", flush=True)
        return [str(filepath)]
