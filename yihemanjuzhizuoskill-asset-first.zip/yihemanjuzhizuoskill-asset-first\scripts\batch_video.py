import argparse
import json
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

try:
    from .videomarker_video_client import (
        DEFAULT_POLL_INTERVAL as VIDEOMARKER_DEFAULT_POLL_INTERVAL,
        DEFAULT_TIMEOUT as VIDEOMARKER_DEFAULT_TIMEOUT,
        VideoMarkerVideoClient,
    )
except ImportError:
    from videomarker_video_client import (
        DEFAULT_POLL_INTERVAL as VIDEOMARKER_DEFAULT_POLL_INTERVAL,
        DEFAULT_TIMEOUT as VIDEOMARKER_DEFAULT_TIMEOUT,
        VideoMarkerVideoClient,
    )


DEFAULT_MAX_WORKERS = 2
DEFAULT_MAX_RETRIES = 0
DEFAULT_SUBMIT_RETRY_INTERVAL = 40


def _get_user_env_value(name: str) -> str | None:
    if os.name != "nt":
        return None
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            value, _ = winreg.QueryValueEx(key, name)
            return str(value) if value else None
    except OSError:
        return None


def load_json_file(path):
    with open(path, "r", encoding="utf-8-sig") as file:
        return json.load(file)


def extract_text_blocks(markdown: str) -> list[str]:
    pattern = re.compile(r"```text\s*(.*?)```", re.DOTALL | re.IGNORECASE)
    return [match.group(1).strip() for match in pattern.finditer(markdown)]


def _compact_prompt(prompt: str) -> str:
    prompt = prompt.replace(
        "【无BGM，添加氛围音，添加音效，添加环境音，所有声音不影响对话】",
        "【无BGM,添加氛围音，添加音效，添加环境音，所有声音不影响对话】",
    )
    return prompt[:3400]


def _is_fatal_error(message: str) -> bool:
    lowered = (message or "").lower()
    fatal_markers = (
        "missing api key",
        "bad key",
        "invalid api key",
        "unauthorized",
        "forbidden",
        "input validation failed",
        "reference asset not found",
        "local file upload to tos failed",
        "inputimagesensitivecontentdetected",
        "privacyinformation",
        "duration must",
        "prompt is empty",
    )
    return any(marker in lowered for marker in fatal_markers)


def load_prompts(path: str) -> list[str]:
    prompt_path = Path(path)
    if prompt_path.suffix.lower() == ".md":
        return extract_text_blocks(prompt_path.read_text(encoding="utf-8-sig"))
    return load_json_file(path)


def scene_key(index: int) -> str:
    return f"scene_{index + 1:02d}"


def choose_provider(provider: str | None = None) -> str:
    user_selected = _get_user_env_value("VIDEO_PROVIDER") or _get_user_env_value("VIDEO_API_PROVIDER")
    process_selected = os.getenv("VIDEO_PROVIDER") or os.getenv("VIDEO_API_PROVIDER")
    if process_selected and process_selected.strip().lower() not in {"auto", "videomarker"}:
        process_selected = None
    selected = (provider or user_selected or process_selected or "auto").strip().lower()
    if selected == "auto":
        return "videomarker"
    if selected != "videomarker":
        raise ValueError(
            f"Configured video provider '{selected}' is not implemented by this skill. "
            "Do not silently fall back to another API. Ask the user for the current approved video API adapter/config."
        )
    return selected


def validate_reference_manifest(reference_assets: dict, count: int, provider: str = "videomarker") -> list[str]:
    errors = []
    for index in range(count):
        key = scene_key(index)
        if key not in reference_assets:
            errors.append(f"{key}: missing reference assets")
            continue
        scene_assets = reference_assets[key]
        total = sum(len(scene_assets.get(name, []) or []) for name in ("characters", "subjects", "props", "scenes", "backgrounds"))
        if total == 0:
            errors.append(f"{key}: no character/scene/prop references")
        for category in ("characters", "subjects", "props", "scenes", "backgrounds"):
            for item in scene_assets.get(category, []) or []:
                if isinstance(item, str):
                    path = item
                elif isinstance(item, dict):
                    path = item.get("path") or item.get("url") or item.get("image")
                else:
                    errors.append(f"{key}: unsupported reference asset entry in {category}")
                    continue
                if not path:
                    errors.append(f"{key}: missing reference asset path/url/image in {category}")
                elif (
                    not str(path).startswith(("http://", "https://", "asset://"))
                    and not Path(path).exists()
                ):
                    errors.append(f"{key}: reference asset not found: {path}")
    return errors


def validate_inputs(prompts, durations, reference_assets, provider: str = "videomarker") -> dict:
    errors = []
    if not isinstance(prompts, list):
        errors.append("prompts must be a JSON string array")
        prompts = []
    if not isinstance(durations, list):
        errors.append("durations must be a JSON integer array")
        durations = []
    if not isinstance(reference_assets, dict):
        errors.append("reference_assets must be a JSON object")
        reference_assets = {}
    if not prompts:
        errors.append("prompts list is empty")
    if len(prompts) != len(durations):
        errors.append(f"prompts and durations length mismatch: {len(prompts)} != {len(durations)}")
    for index, duration in enumerate(durations):
        if not isinstance(duration, int) or duration < 4 or duration > 15:
            errors.append(f"{scene_key(index)}: duration must be an integer from 4 to 15")
    errors.extend(validate_reference_manifest(reference_assets, len(prompts), provider=provider))
    return {
        "status": "success" if not errors else "failed",
        "provider": provider,
        "prompt_count": len(prompts),
        "duration_count": len(durations),
        "scene_count": len(prompts),
        "errors": errors,
    }


def _generate_single(
    reference_assets,
    prompt,
    duration,
    output_dir,
    filename,
    index,
    max_retries,
    asset_subdir,
    submit_retry_interval,
    provider,
):
    last_error = None
    poll_interval = int(os.getenv("VIDEOMARKER_POLL_INTERVAL", VIDEOMARKER_DEFAULT_POLL_INTERVAL))
    timeout = int(os.getenv("VIDEOMARKER_TIMEOUT", VIDEOMARKER_DEFAULT_TIMEOUT))
    retry_interval = int(os.getenv("VIDEOMARKER_SUBMIT_RETRY_INTERVAL", submit_retry_interval))
    filepath = os.path.join(output_dir, filename)

    if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
        return {
            "index": index,
            "status_label": "success",
            "filepath": filepath,
            "filename": filename,
            "error": None,
            "skipped_existing": True,
        }

    attempt = 0
    unlimited = max_retries <= 0

    while unlimited or attempt < max_retries:
        attempt += 1
        try:
            client = VideoMarkerVideoClient()
            result = client.generate_from_references(
                reference_assets=reference_assets,
                prompt=_compact_prompt(prompt),
                duration=int(duration),
                output_dir=output_dir,
                filename=filename,
                poll_interval=poll_interval,
                timeout=timeout,
                asset_subdir=asset_subdir,
            )
            print(f"[{index + 1}] generated: {filename}", flush=True)
            result.update({"index": index, "status_label": "success", "filename": filename, "error": None})
            return result
        except Exception as exc:
            last_error = str(exc)
            total = "unlimited" if unlimited else str(max_retries)
            print(f"[{index + 1}] submit attempt {attempt}/{total} failed: {last_error}", flush=True)

            if _is_fatal_error(last_error):
                print(f"[{index + 1}] fatal error, stop retrying: {last_error}", flush=True)
                break

            if not unlimited and attempt >= max_retries:
                break

            print(f"[{index + 1}] will resubmit in {retry_interval}s: {filename}", flush=True)
            time.sleep(retry_interval)

    return {
        "index": index,
        "status_label": "failed",
        "filepath": os.path.join(output_dir, filename),
        "filename": filename,
        "error": last_error,
    }


def batch_omni_asset_video_generate(
    prompts,
    durations,
    reference_assets,
    output_dir,
    prefix="scene_",
    ext=".mp4",
    max_workers=DEFAULT_MAX_WORKERS,
    max_retries=DEFAULT_MAX_RETRIES,
    filenames=None,
    asset_subdir=None,
    submit_retry_interval=DEFAULT_SUBMIT_RETRY_INTERVAL,
    provider=None,
):
    provider_name = choose_provider(provider)
    validation = validate_inputs(prompts, durations, reference_assets, provider=provider_name)
    if validation["status"] != "success":
        return {"status": "failed", "message": "input validation failed", "validation": validation, "results": []}

    os.makedirs(output_dir, exist_ok=True)
    if filenames and len(filenames) == len(prompts):
        names = filenames
    else:
        names = [f"{prefix}{i + 1:02d}{ext}" for i in range(len(prompts))]

    start_time = time.time()
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(
                _generate_single,
                reference_assets[scene_key(i)],
                prompt,
                duration,
                output_dir,
                name,
                i,
                max_retries,
                asset_subdir,
                submit_retry_interval,
                provider_name,
            )
            for i, (prompt, duration, name) in enumerate(zip(prompts, durations, names))
        ]
        for future in as_completed(futures):
            results.append(future.result())

    results.sort(key=lambda item: item["index"])
    succeeded = [item for item in results if item["status_label"] == "success"]
    failed = [item for item in results if item["status_label"] == "failed"]

    return {
        "status": "success" if not failed else "partial" if succeeded else "failed",
        "provider": provider_name,
        "total": len(prompts),
        "succeeded": len(succeeded),
        "failed": len(failed),
        "elapsed_seconds": round(time.time() - start_time, 1),
        "results": results,
        "saved_files": [item["filepath"] for item in succeeded],
        "failed_indices": [item["index"] for item in failed],
    }


def main():
    parser = argparse.ArgumentParser(description="Batch generate all-reference video clips with the configured video provider")
    parser.add_argument("command", nargs="?", default="generate", choices=["generate", "validate", "balance"])
    parser.add_argument("--prompts-file", help="JSON string array or markdown file with text code blocks")
    parser.add_argument("--durations-file", help="JSON integer array")
    parser.add_argument("--reference-assets-file", help="JSON object mapping scene_XX to character/scene/prop references")
    parser.add_argument("--output-dir", help="Video output directory")
    parser.add_argument("--prefix", default="scene_")
    parser.add_argument("--ext", default=".mp4")
    parser.add_argument("--max-workers", type=int, default=DEFAULT_MAX_WORKERS)
    parser.add_argument(
        "--max-retries",
        type=int,
        default=DEFAULT_MAX_RETRIES,
        help="Submit retry count per scene. Use 0 for unlimited retries until a video is generated.",
    )
    parser.add_argument(
        "--submit-retry-interval",
        type=int,
        default=DEFAULT_SUBMIT_RETRY_INTERVAL,
        help="Seconds to wait before resubmitting a failed or concurrency-limited video task.",
    )
    parser.add_argument("--filenames-file")
    parser.add_argument("--asset-subdir")
    parser.add_argument("--provider", default=None, choices=["auto", "videomarker"], help="Video backend. Defaults to VIDEO_PROVIDER/VIDEO_API_PROVIDER, then videomarker.")
    args = parser.parse_args()

    if args.command == "balance":
        provider_name = choose_provider(args.provider)
        client = VideoMarkerVideoClient()
        print(json.dumps(client.get_balance(), ensure_ascii=False, indent=2))
        return

    if not args.prompts_file or not args.durations_file or not args.reference_assets_file:
        raise SystemExit("Error: provide --prompts-file, --durations-file, and --reference-assets-file")

    prompts = load_prompts(args.prompts_file)
    durations = load_json_file(args.durations_file)
    reference_assets = load_json_file(args.reference_assets_file)

    if args.command == "validate":
        provider_name = choose_provider(args.provider)
        print(json.dumps(validate_inputs(prompts, durations, reference_assets, provider=provider_name), ensure_ascii=False, indent=2))
        return

    if not args.output_dir:
        raise SystemExit("Error: provide --output-dir")

    filenames = load_json_file(args.filenames_file) if args.filenames_file else None
    result = batch_omni_asset_video_generate(
        prompts=prompts,
        durations=durations,
        reference_assets=reference_assets,
        output_dir=args.output_dir,
        prefix=args.prefix,
        ext=args.ext,
        max_workers=args.max_workers,
        max_retries=args.max_retries,
        filenames=filenames,
        asset_subdir=args.asset_subdir,
        submit_retry_interval=args.submit_retry_interval,
        provider=args.provider,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "failed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
