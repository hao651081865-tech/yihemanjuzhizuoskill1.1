﻿# 漫剧制作使用示例

## 当前标准流程

输入剧本或故事创意后，严格按以下顺序执行：

1. 剧本整理与集数/场景拆分
2. 先生成整部剧全部人物、场景、道具参考资产
3. 参考资产质检：人物撞脸风险、白底三视图、肢体结构、场景/道具合规；出现明星脸、公众人物相似、风格错误或隐私拦截时，先停下询问用户，不得擅自改风格或换模型
4. 展示整部剧全部人物、场景、道具参考资产预览，明确询问用户是否确认继续生成整部剧所有视频；未获得确认前不得生成分镜视频提示词，不得提交视频任务
5. 用户确认全剧图片资产后，生成当前已批准视频 API 可用的全剧分镜视频提示词
6. 用“人物资产 + 场景资产 + 道具资产 + 分镜提示词”批量执行整部剧全能参考出视频
7. 视频逐段质检：穿帮、重复人物、缺胳膊少腿、多肢、脸和服装漂移、明星脸；失败段先报告原因，涉及明星脸/公众人物相似/风格问题时必须询问用户后再重生
8. 合并视频并交付本地视频；最终合成片保存到 E 盘，只有需要公网链接时再上传 TOS

禁止生成分镜首帧图、故事版分镜图、`frames.json`、`storyboard_images.json`，禁止回到 first-frame 视频流程。

资产去重规则：人物、场景、道具图片只保留在 `{CODEX_ASSET_DIR}/{剧名}/人物资产/场景资产/道具资产/` 对应分类目录；分镜视频只保留在 `{CODEX_ASSET_DIR}/{剧名}/视频/{集数}/`；过程任务目录只保存 prompts、JSON 清单和文档，不再保存同一图片或视频副本。

## 示例：现代都市真人写实短剧

**用户输入**：
```text
第一集
场1-1 高档小区楼下 日/外
人物：程俞礼、江杏梅、沈泽宇、乔云儿
△江杏梅坐在副驾驶催促程俞礼搬行李……
```

**资产目录**：
```text
{CODEX_ASSET_DIR}/软饭男机场反转/
├── 人物资产/
├── 场景资产/
├── 道具资产/
└── 视频/
    └── 第一集/
```

过程目录只保存 `requirements.md`、`plot.md`、`script.md`、`characters.md`、`prompts/` 和各类 JSON 清单；不得再出现 `characters/`、`assets/`、`videos/`、`final/` 这类重复产物目录。

## 人物资产提示词示例

人物资产必须是 16:9 白底角色设定图，左侧正脸特写，右侧正面/侧面/背面三视图。

```text
realistic live-action vertical drama style, cinematic lighting, ultra clear 8k, 16:9 horizontal character design sheet, character reference asset, Cheng Yuli, Chinese man in his early thirties, gentle handsome face, short neat black hair, wearing a blue T-shirt and black trousers, ordinary family-man appearance, split layout, left one-third area shows front close-up portrait with complete frontal face and clear facial features, right two-thirds area shows three-view full-body lineup arranged left to right: front view, side view, back view, equal height, full body head-to-toe visible, neutral standing pose, pure white seamless background, no shadow, no environment, no props, no handheld objects, no carried items, no bags, no handbag, no purse, no shoulder bag, no crossbody bag, no backpack, no phone, no keys, no document, no cup, no umbrella, no tool, no weapon, no pouch, high detail, 4K
```

## 场景资产提示词示例

场景资产必须是可复用环境参考，不绑定某个镜头瞬间。

```text
realistic live-action vertical drama style, cinematic lighting, ultra clear 8k, reusable environment reference asset, wide complete panoramic establishing composition of a luxury residential compound entrance in daytime, private driveway, modern apartment towers, parked car area, landscaped greenery, security gate, foreground, midground, background and spatial boundaries clearly visible, enough empty space for later character placement, no characters, no close crop, no storyboard frame, no specific camera action, no subtitles, no onscreen text
```

## 道具资产提示词示例

道具资产必须“一物一图”。汽车、旅行箱、手机、钥匙都要分别生成，不能合成一张图。

```text
realistic live-action vertical drama style, cinematic lighting, ultra clear 8k, reusable prop reference asset, single standalone prop only, black luxury sedan, glossy black paint, modern four-door car body, visible front grille and side profile details, prop design sheet, split layout, left one-third area shows main front close-up view of this single prop, right two-thirds area shows three-view lineup of the same single prop arranged left to right: front view, side view, back view, equal height, pure white seamless background, subject centered and fully visible, no characters, no hands, no road, no luggage, no other objects, no second prop, no grouped props
```

```text
realistic live-action vertical drama style, cinematic lighting, ultra clear 8k, reusable prop reference asset, single standalone prop only, hard-shell travel suitcase, dark gray textured shell, telescopic handle, four small wheels, prop design sheet, split layout, left one-third area shows main front close-up view of this single prop, right two-thirds area shows three-view lineup of the same single prop arranged left to right: front view, side view, back view, equal height, pure white seamless background, subject centered and fully visible, no characters, no hands, no car, no phone, no key, no other objects, no grouped props
```

## 分镜视频提示词 JSON 示例

`storyboard-director.md` 输出 `segments`，再拆成 `prompts.json` 和 `durations.json`。每段视频提示词只描述画面、动作、对白、运镜、光影、音效，不包含首帧图。

```json
{
  "segments": [
    {
      "episode_number": 1,
      "scene_number": 1,
      "segment_number": 1,
      "title": "小区楼下的羞辱",
      "duration_seconds": 12,
      "video_prompt": "【第1集-第1场-分镜1】\n【无显示字幕，无显示台词，无显示字符】\n【出场人物：@程俞礼、@江杏梅】【场景：@高档小区楼下】【道具：@黑色轿车、@旅行箱】\n戏剧任务：展现@程俞礼在家人面前被催促和轻视，为后续冲突铺垫。\n1 时长 00:00-00:04\n核心画面提示词：中景，平视，@高档小区楼下日光明亮，@程俞礼站在画面右侧拖着@旅行箱靠近@黑色轿车后备箱，@江杏梅从副驾驶车窗探出头，脸色不耐，镜头缓慢推进。\n对话/音效：@江杏梅：（不耐烦）你还愣着干什么，没看见我在等你吗？车流声、行李轮滚动声。\n2 时长 00:04-00:08\n核心画面提示词：近景，侧拍，@程俞礼弯腰扶住@旅行箱拉杆，抬头朝车内赔笑，@江杏梅肩膀仍压在车窗边缘，车身反光清晰。\n对话/音效：@程俞礼：（讨好）马上，亲爱的！打开后备箱，我放行李。\n3 时长 00:08-00:12\n核心画面提示词：特写，微俯拍，@程俞礼把@旅行箱推向车尾，@江杏梅从车窗里冷眼看着@程俞礼，午后自然光照在车漆和地面。\n对话/音效：后备箱开启声、远处小区保安对讲机声。\n【写实风格，电影级光效，氛围感照片，超清，8k。场景氛围，光影介质】\n【无BGM,添加氛围音，添加音效，添加环境音，所有声音不影响对话】"
    }
  ]
}
```

## 生成文件示例

**prompts.json** 必须是纯字符串数组：
```json
[
  "realistic live-action vertical drama style, cinematic lighting, ultra clear 8k. Use references: @程俞礼, @江杏梅, @黑色轿车, @旅行箱, @高档小区楼下..."
]
```

**durations.json** 必须是纯整数数组：
```json
[12]
```

**reference_assets_manifest.json** 使用人物、场景、道具资产路径：
```json
{
  "scene_01": {
    "characters": [
      "D:/codex资产/软饭男机场反转/人物资产/char_cheng_yuli.png",
      "D:/codex资产/软饭男机场反转/人物资产/char_jiang_xingmei.png"
    ],
    "scenes": [
      "D:/codex资产/软饭男机场反转/场景资产/scene_luxury_compound.png"
    ],
    "props": [
      "D:/codex资产/软饭男机场反转/道具资产/prop_black_sedan.png",
      "D:/codex资产/软饭男机场反转/道具资产/prop_suitcase.png"
    ]
  }
}
```

> 参考图数量、上传方式和模型限制以当前已批准的视频 API 文档/适配器为准。不得在示例或脚本中写死临时 API，也不得在失败时擅自切换 provider、模型或画风。

## 质检与重生示例

人物资产生成后先检查：

```text
角色资产质检：程俞礼
- 撞脸风险：通过，原创脸，不明显像现实明星/公众人物
- 白底三视图：通过
- 人体结构：通过
- 单人资产：通过
结果：可用于全能参考出视频
```

如果出现明星脸/公众人物相似、真实人物隐私拦截或风格错误，先报告问题并询问用户，不得擅自改风格、改模型或重生。用户确认可以重生后，提示词追加：

```text
original fictional non-celebrity face, avoid resemblance to real actors or public figures, distinct facial proportions, corrected complete human anatomy, full limbs visible, no extra arms, no extra legs, no duplicated person
```

整部剧全部人物、场景、道具参考资产都通过质检后，必须展示预览并询问：

```text
整部剧全部图片资产已完成并通过初步质检。请确认是否继续生成整部剧所有视频？
```

只有用户明确确认整部剧图片资产后，才能生成分镜视频提示词并执行视频生成。

视频生成后逐段检查：

```text
scene_02.mp4 质检失败：
- 后排多出一个重复的沈泽宇
- 程俞礼左手短暂缺失
处理：报告失败原因；只处理 scene_02，保留其他已通过视频。若失败原因包含明星脸/公众人物相似，必须先询问用户再重生。
```

用户确认可以重生后，重生视频提示词追加：

```text
single instance of each character only, complete human anatomy, no duplicated people, no extra limbs, no missing limbs, consistent face and outfit, original fictional non-celebrity faces, avoid resemblance to real actors or public figures, no visible text, no watermark, maintain exact character count
```

## 全能参考出视频命令

```bash
python scripts/batch_video.py validate \
  --prompts-file prompts.json \
  --durations-file durations.json \
  --reference-assets-file reference_assets_manifest.json

python scripts/batch_video.py generate \
  --prompts-file prompts.json \
  --durations-file durations.json \
  --reference-assets-file reference_assets_manifest.json \
  --output-dir "D:/codex资产/软饭男机场反转/视频/第一集" \
  --max-retries 0 \
  --submit-retry-interval 40
```

如果接口返回并发上限、排队失败、临时网络失败或 HTTP 429，可在当前已批准 API 和同一模型下按间隔重试，不能跳过该分镜。账号凭据缺失/无效、余额不足、模型无权限、输入校验失败、参考资产缺失、内容/隐私/明星脸风险等情况必须停止并报告，不得擅自换 API、换模型、改画风或绕过。

> 账号凭据由每个使用者在自己的环境变量中配置，示例和 skill 文档中不得写入任何真实 API key。
> 当前视频 API 如果只接受公网 URL，脚本需要使用已批准的上传适配器把本地参考图转成公网 URL；上传、认证、查询和下载规则以当前已批准的视频 API 文档为准。

## 最终目录结构

```text
D:/codex资产/软饭男机场反转/
├── 人物资产/
│   ├── char_cheng_yuli.png
│   ├── char_jiang_xingmei.png
│   └── ...
├── 场景资产/
│   ├── scene_luxury_compound.png
│   └── scene_airport_hall.png
├── 道具资产/
│   ├── prop_black_sedan.png
│   ├── prop_suitcase.png
│   ├── prop_smartphone.png
│   └── prop_car_key.png
└── 视频/
    └── 第一集/
        ├── scene_01.mp4
        ├── scene_02.mp4
        └── 第一集_final.mp4
```

