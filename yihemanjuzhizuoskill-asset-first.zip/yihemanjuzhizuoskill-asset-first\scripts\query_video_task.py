"""Deprecated legacy video poller.

The current workflow polls and downloads videos inside scripts/batch_video.py.
Keep this file only as a clear compatibility guard for old references.
"""

import sys


MESSAGE = """query_video_task.py is deprecated for comic-drama-master.

Use:
  python scripts/batch_video.py generate --prompts-file prompts.json --durations-file durations.json --reference-assets-file reference_assets_manifest.json --output-dir "<CODEX_ASSET_DIR>/<剧名>/视频/第一集" --max-retries 0 --submit-retry-interval 40

batch_video.py will submit, poll, retry concurrency failures, and download scene_NN.mp4 files.
"""


if __name__ == "__main__":
    print(MESSAGE, file=sys.stderr)
    raise SystemExit(2)
